<?php
require_once '../conn.php';
require_once 'header.php';
?>

<div class="card p-1 text-center">Page</div>

<?php
require_once 'footer.php';
?>